﻿namespace DataSet1TableAdapters
{
    internal class CourseTableAdapter
    {
    }
}
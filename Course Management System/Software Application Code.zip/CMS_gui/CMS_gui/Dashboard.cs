﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cMSDataSet.COURSE' table. You can move, or remove it, as needed.
        }

        
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.cOURSETableAdapter.Fill(this.cMSDataSet.COURSE);
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
            {
                MessageBox.Show("Please select a course to update from the table.");
                return;
            }

            if (dataGridView1.CurrentRow.Cells["cOURSEIDDataGridViewTextBoxColumn"].Value == null)
            {
                MessageBox.Show("Selected course does not have a valid ID.");
                return;
            }

            int courseId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["cOURSEIDDataGridViewTextBoxColumn"].Value);

            if (string.IsNullOrWhiteSpace(textBoxUserId.Text) ||
                string.IsNullOrWhiteSpace(textBoxCourseName.Text) ||
                string.IsNullOrWhiteSpace(textBoxDuration.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            if (!int.TryParse(textBoxUserId.Text, out int userId))
            {
                MessageBox.Show("Your ID must be a valid number.");
                return;
            }

            string courseName = textBoxCourseName.Text;
            string duration = textBoxDuration.Text;
            int visibility = checkBoxVisibility.Checked ? 1 : 0;

            var result = MessageBox.Show(
                "Are you sure you want to update the course info?",
                "Confirm Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
                return;

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = "UPDATE [COURSE] SET [USER_ID]=@UserId, [NAME]=@Name, [DURATION]=@Duration, [VISIBILITY]=@Visibility WHERE [COURSE_ID]=@CourseId;";

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                using (var command = new System.Data.SqlClient.SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@Name", courseName);
                    command.Parameters.AddWithValue("@Duration", duration);
                    command.Parameters.AddWithValue("@Visibility", visibility);
                    command.Parameters.AddWithValue("@CourseId", courseId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        this.cOURSETableAdapter.Fill(this.cMSDataSet.COURSE);
                        MessageBox.Show("Course updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No course was updated. Please check your selection.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

     
        
        private void button5_Click(object sender, EventArgs e)
        {
            using (var profileForm = new ProfileUpdateForm())
            {
                profileForm.ShowDialog(this);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (var examForm = new ExamAdding())
            {
                examForm.ShowDialog(this);
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBoxVisibility_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.cOURSETableAdapter.Fill(this.cMSDataSet.COURSE);
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxUserId.Text) ||
                string.IsNullOrWhiteSpace(textBoxCourseName.Text) ||
                string.IsNullOrWhiteSpace(textBoxDuration.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            if (!int.TryParse(textBoxUserId.Text, out int userId))
            {
                MessageBox.Show("Your ID must be a valid number.");
                return;
            }

            string courseName = textBoxCourseName.Text;
            string duration = textBoxDuration.Text;
            int visibility = checkBoxVisibility.Checked ? 1 : 0;

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = "INSERT INTO [COURSE] ([USER_ID], [NAME], [DURATION], [VISIBILITY]) VALUES (@UserId, @Name, @Duration, @Visibility);";

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                using (var command = new System.Data.SqlClient.SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@Name", courseName);
                    command.Parameters.AddWithValue("@Duration", duration);
                    command.Parameters.AddWithValue("@Visibility", visibility);

                    connection.Open();
                    command.ExecuteNonQuery();
                }

                this.cOURSETableAdapter.Fill(this.cMSDataSet.COURSE);
                MessageBox.Show("Course added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
            {
                MessageBox.Show("Please select a course to delete from the table.");
                return;
            }

            if (dataGridView1.CurrentRow.Cells["cOURSEIDDataGridViewTextBoxColumn"].Value == null)
            {
                MessageBox.Show("Selected course does not have a valid ID.");
                return;
            }

            int courseId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["cOURSEIDDataGridViewTextBoxColumn"].Value);

            var result = MessageBox.Show(
                "Are you sure you want to delete this course?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result != DialogResult.Yes)
                return;

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = "DELETE FROM [COURSE] WHERE [COURSE_ID]=@CourseId;";

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                using (var command = new System.Data.SqlClient.SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CourseId", courseId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        this.cOURSETableAdapter.Fill(this.cMSDataSet.COURSE);
                        MessageBox.Show("Course deleted successfully.");
                    }
                    else
                    {
                        MessageBox.Show("No course was deleted. Please check your selection.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            using (var topFiveForm = new TopFive())
            {
                topFiveForm.ShowDialog(this);
            }
        }
    }
}

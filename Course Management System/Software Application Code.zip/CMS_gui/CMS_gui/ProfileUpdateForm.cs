﻿using System;
using System.Data;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class ProfileUpdateForm : Form
    {
        private int LastUserId { get; set; } // Tracks the last USER_ID

        public ProfileUpdateForm()
        {
            InitializeComponent();
        }

        private void ProfileUpdateForm_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";

            // Get the last USER_ID
            string getLastIdQuery = "SELECT TOP 1 USER_ID FROM INSTRUCTOR ORDER BY USER_ID DESC";
            using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
            using (var command = new System.Data.SqlClient.SqlCommand(getLastIdQuery, connection))
            {
                connection.Open();
                var result = command.ExecuteScalar();
                if (result != null)
                {
                    LastUserId = Convert.ToInt32(result);
                }
                else
                {
                    MessageBox.Show("No instructor found.");
                    this.Close();
                    return;
                }
            }

            // Load the last instructor's data
            string query = @"SELECT USER_FNAME, USER_LNAME, USER_EMAIL, OFFICE_HOURS
                             FROM INSTRUCTOR
                             WHERE USER_ID = @UserId";

            using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
            using (var command = new System.Data.SqlClient.SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserId", LastUserId);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        textBoxFirstName.Text = reader["USER_FNAME"].ToString();
                        textBoxLastName.Text = reader["USER_LNAME"].ToString();
                        textBoxEmail.Text = reader["USER_EMAIL"].ToString();
                        textBoxOfficeHours.Text = reader["OFFICE_HOURS"].ToString();
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Validate input
            if (string.IsNullOrWhiteSpace(textBoxFirstName.Text) ||
                string.IsNullOrWhiteSpace(textBoxLastName.Text) ||
                string.IsNullOrWhiteSpace(textBoxEmail.Text) ||
                string.IsNullOrWhiteSpace(textBoxOfficeHours.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            var result = MessageBox.Show(
                "Are you sure you want to update your profile?",
                "Confirm Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
                return;

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = @"UPDATE INSTRUCTOR 
                             SET USER_FNAME = @FirstName, USER_LNAME = @LastName, USER_EMAIL = @Email, 
                                 OFFICE_HOURS = @OfficeHours
                             WHERE USER_ID = @UserId";

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                using (var command = new System.Data.SqlClient.SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FirstName", textBoxFirstName.Text);
                    command.Parameters.AddWithValue("@LastName", textBoxLastName.Text);
                    command.Parameters.AddWithValue("@Email", textBoxEmail.Text);
                    command.Parameters.AddWithValue("@OfficeHours", textBoxOfficeHours.Text);
                    command.Parameters.AddWithValue("@UserId", LastUserId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile updated successfully.");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No profile was updated. Please check your data.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBoxFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
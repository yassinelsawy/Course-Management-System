﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class MyCourses : Form
    {
        public MyCourses()
        {
            InitializeComponent();
        }

        private void MyCourses_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            DataTable dt = new DataTable();

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();
                    int userId;
                    using (var cmdUser = new System.Data.SqlClient.SqlCommand(
                        "SELECT MAX(USER_ID) FROM STUDENT", connection))
                    {
                        object result = cmdUser.ExecuteScalar();
                        if (result == DBNull.Value || result == null)
                        {
                            MessageBox.Show("No students found.");
                            return;
                        }
                        userId = Convert.ToInt32(result);
                    }

             
                    using (var cmd = new System.Data.SqlClient.SqlCommand(
                        @"SELECT C.COURSE_ID, C.NAME
                  FROM COURSE C
                  INNER JOIN REGISTERS R ON C.COURSE_ID = R.COURSE_ID
                  WHERE R.USER_ID = @UserId", connection))
                    {
                        cmd.Parameters.AddWithValue("@UserId", userId);
                        using (var adapter = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            adapter.Fill(dt);
                        }
                    }
                }

                dataGridView1.DataSource = dt;
                if (dataGridView1.Columns["COURSE_ID"] != null)
                {
                    dataGridView1.Columns["COURSE_ID"].HeaderText = "Course ID";
                    dataGridView1.Columns["COURSE_ID"].ReadOnly = true;
                }
                if (dataGridView1.Columns["NAME"] != null)
                    dataGridView1.Columns["NAME"].HeaderText = "Course Name";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading registered courses: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿using System;
using System.Data;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class StudentView : Form
    {
        public StudentView()
        {
            InitializeComponent();
            this.Load += StudentView_Load;
        }

        private void StudentView_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            DataTable dt = new DataTable();

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                using (var command = new System.Data.SqlClient.SqlCommand("SELECT COURSE_ID, NAME, DURATION FROM COURSE", connection))
                using (var adapter = new System.Data.SqlClient.SqlDataAdapter(command))
                {
                    adapter.Fill(dt);
                }

                dataGridView1.DataSource = dt;

                // Only set headers if columns exist
                if (dataGridView1.Columns["COURSE_ID"] != null)
                {
                    dataGridView1.Columns["COURSE_ID"].HeaderText = "Course ID";
                    dataGridView1.Columns["COURSE_ID"].ReadOnly = true;
                }
                if (dataGridView1.Columns["NAME"] != null)
                    dataGridView1.Columns["NAME"].HeaderText = "Course Name";
                if (dataGridView1.Columns["DURATION"] != null)
                    dataGridView1.Columns["DURATION"].HeaderText = "Duration";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading courses: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
            {
                MessageBox.Show("Please select a course to register.");
                return;
            }

            var courseIdObj = dataGridView1.CurrentRow.Cells[0].Value;
            if (courseIdObj == null)
            {
                MessageBox.Show("Selected course does not have a valid ID.");
                return;
            }
            int courseId = Convert.ToInt32(courseIdObj);

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            int userId;
            int semesterId;

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
                {
                    connection.Open();

                
                    using (var cmdUser = new System.Data.SqlClient.SqlCommand(
                        "SELECT MAX(USER_ID) FROM STUDENT", connection))
                    {
                        object result = cmdUser.ExecuteScalar();
                        if (result == DBNull.Value || result == null)
                        {
                            MessageBox.Show("No students found.");
                            return;
                        }
                        userId = Convert.ToInt32(result);
                    }

                    using (var cmdSemester = new System.Data.SqlClient.SqlCommand(
                        "SELECT TOP 1 SEMESTER_ID FROM SEMESTER WHERE IS_CURRENT = 1 ORDER BY SEMESTER_ID DESC", connection))
                    {
                        object result = cmdSemester.ExecuteScalar();
                        if (result == DBNull.Value || result == null)
                        {
                            MessageBox.Show("No current semester found.");
                            return;
                        }
                        semesterId = Convert.ToInt32(result);
                    }

                    using (var cmdRegister = new System.Data.SqlClient.SqlCommand(
     "INSERT INTO REGISTERS (COURSE_ID, SEMESTER_ID, USER_ID, FINAL_GRADE) VALUES (@CourseId, @SemesterId, @UserId, @FinalGrade)", connection))
                    {
                        cmdRegister.Parameters.AddWithValue("@CourseId", courseId);
                        cmdRegister.Parameters.AddWithValue("@SemesterId", semesterId);
                        cmdRegister.Parameters.AddWithValue("@UserId", userId);
                        cmdRegister.Parameters.AddWithValue("@FinalGrade", 0); 

                        cmdRegister.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Registered in course successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (var myCoursesForm = new MyCourses())
            {
                this.Hide();
                myCoursesForm.ShowDialog();
                this.Show();
            }
        }
    }
}
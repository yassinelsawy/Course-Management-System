﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class ExamAdding : Form
    {
        public ExamAdding()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string examType = ExamTypeBox.Text.Trim();
            string courseIdText = ExamCIDBox.Text.Trim();
            string examDurationText = DurationBox.Text.Trim();

            // Validate input
            if (string.IsNullOrWhiteSpace(examType) ||
                string.IsNullOrWhiteSpace(courseIdText) ||
                string.IsNullOrWhiteSpace(examDurationText))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (!int.TryParse(courseIdText, out int courseId) ||
                !int.TryParse(examDurationText, out int examDuration))
            {
                MessageBox.Show("Course ID and Exam Duration must be numbers.");
                return;
            }

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";

            string query = "INSERT INTO [dbo].[EXAM] ([COURSE_ID], [EXAM_DURATION], [EXAM_TYPE]) VALUES (@CourseId, @ExamDuration, @ExamType)";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@CourseId", courseId);
                    cmd.Parameters.AddWithValue("@ExamDuration", examDuration);
                    cmd.Parameters.AddWithValue("@ExamType", examType);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Exam added successfully.");
                ExamTypeBox.Clear();
                ExamCIDBox.Clear();
                DurationBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding exam: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string courseIdText = CID_Delete.Text.Trim();

            if (string.IsNullOrWhiteSpace(courseIdText))
            {
                MessageBox.Show("Please enter the Course ID to delete.");
                return;
            }

            if (!int.TryParse(courseIdText, out int courseId))
            {
                MessageBox.Show("Course ID must be a number.");
                return;
            }

            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = "DELETE FROM [dbo].[EXAM] WHERE [COURSE_ID] = @CourseId";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@CourseId", courseId);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Exam(s) deleted successfully.");
                        ExamCIDBox.Clear();
                    }
                    else
                    {
                        MessageBox.Show("No exam found with the specified Course ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting exam: " + ex.Message);
            }
        }

        private void ExamAdding_Load(object sender, EventArgs e)
        {

        }

        private void ExamType_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMS_gui
{
    public partial class TopFive : Form
    {
        public TopFive()
        {
            InitializeComponent();
        }

        private void TopFive_Load(object sender, EventArgs e)
        {
            string connectionString = "Data Source=HAZEM\\SQLEXPRESS;Initial Catalog=CMS;Integrated Security=True;Encrypt=False";
            string query = @"
        SELECT TOP 5 
            st.USER_ID, 
            r.FINAL_GRADE,
            st.USER_FNAME + ' ' + st.USER_LNAME AS stName
        FROM [dbo].[STUDENT] st, [dbo].[SEMESTER] s, [dbo].[REGISTERS] r
        WHERE r.SEMESTER_ID = s.SEMESTER_ID
            AND r.USER_ID = st.USER_ID
            AND YEAR(s.START_DATE) = 2024
        ORDER BY r.FINAL_GRADE DESC;
    ";

            using (var connection = new System.Data.SqlClient.SqlConnection(connectionString))
            using (var adapter = new System.Data.SqlClient.SqlDataAdapter(query, connection))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
